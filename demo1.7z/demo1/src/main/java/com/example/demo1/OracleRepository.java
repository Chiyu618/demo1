package com.example.demo1;

import org.springframework.data.repository.CrudRepository;

public interface OracleRepository extends CrudRepository<Sample, Integer> {

  
} 
