package com.example.demo1;

import org.springframework.data.annotation.Id;

import lombok.Data;

@Data
public class Sample {

	@Id
	private Integer id;
	private String name;
	private Integer gender;
	private Integer age;
}
