package com.example.demo1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo1Application.class, args)
		.getBean(Demo1Application.class).execute();
		System.out.println("asd");
	}
	@Autowired
	private OracleRepository repository;
	
	public void execute() {
		Iterable<Sample> samples = repository.findAll();
		for(Sample sample : samples) {
			System.out.println(sample);
		}
	}
}
